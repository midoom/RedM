Config = {}


Config.Komut = "<"
Config.InventoryLimit = 5000 

Config.Yazikullan = true
Config.Ac = { 
	['key'] = 0xD9D0E1C0, -- SPACE
	['text'] = "press ~e~[SPACE] ~q~key and access stash",
	} 
Config.Kordinat = {
    [1] = {
        coords={-242.4697, 753.7005, 117.6894}
    }
} 

Config.Language = {
    InventoryName = 'Custom Stash',
}