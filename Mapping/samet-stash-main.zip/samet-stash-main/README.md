It is a simple stash script. Enjoy
