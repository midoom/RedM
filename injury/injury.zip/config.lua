Config = {}

Config.settings = {
    {
        bleedingEffect = true, -- default: true
        screenOverlay = true, -- default: true
        clumsiness = true, -- default: true
        soundEffect = true, -- default: true
        canBeKnockedOut = true, -- default: true
        injuryThreshold = 50 -- default: 50, max: 200 | activates injured effect when injuryThreshold/playerHealth value is reached
    }
}